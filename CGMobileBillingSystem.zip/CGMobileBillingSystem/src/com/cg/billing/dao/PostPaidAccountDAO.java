package com.cg.billing.dao;

import java.util.List;

import com.cg.billing.beans.PostpaidAccount;

public interface PostPaidAccountDAO {
	PostpaidAccount save(PostpaidAccount postpaidAccount);
	boolean update(PostpaidAccount postpaidAccount);
boolean remove(PostpaidAccount postpaidAccount);
	List<PostpaidAccount> findAll();
	PostpaidAccount findOne(long mobileNo);
}
