package com.cg.billing.dao;

import java.util.List;
import java.util.Map;

import com.cg.billing.beans.Plan;

public interface PlanDAO {
	Plan save(Plan plans);
	boolean update(Plan plans);
	Plan findOne(int i);
	Map<Integer, Plan> findAll();
}
