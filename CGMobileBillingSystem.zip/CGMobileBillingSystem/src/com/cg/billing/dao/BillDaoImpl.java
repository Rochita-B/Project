package com.cg.billing.dao;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.beans.Bill;


public class BillDaoImpl implements BillDAO {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");


	@Override
	public Bill save(Bill bills) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.persist(bills);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return bills;		
	}

	@Override
	public boolean update(Bill bills) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.merge(bills);
		entityManager.getTransaction().commit();
		entityManager.close();
				return false;
	}

	@Override
	public Bill findOne(int  billID) {
		return entityManagerFactory.createEntityManager().find(Bill.class, billID);
		
	}

	@Override
	public HashMap<Integer, Bill> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
