package com.cg.project;

public class Person 
{
	private String firstName;
	private String lastName;
	private char gender;
	
	Person()
	{
		firstName = "";
		lastName = "";
		gender = '\0';
	}
	
	public Person(String firstName, String lastName,char gender)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	
	public void setFirstName(String fname)
	{
		firstName = fname;
	}
	
	public void setLastName(String lname)
	{
		lastName = lname;
	}
	
	public void setGender(char gen)
	{
		gender = gen;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public char getGender()
	{
		return gender;
	}

	public String displayDetails() {
		return "Firstname="+firstName+" LastName="+lastName+" Gender="+gender;
	}
	
	
}
