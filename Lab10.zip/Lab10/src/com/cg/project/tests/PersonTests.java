package com.cg.project.tests;
import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.project.Person;

public class PersonTests {

	@Test
	public void testForFirstName() {
		Assert.assertEquals("Rochita", new Person("Rochita","Bagchi",'F').getFirstName());
	}
	
	@Test
	public void testForLastName() {
		Assert.assertEquals("Bagchi", new Person("Rochita","Bagchi",'F').getLastName());
	}
	
	@Test
	public void testForGender() {
		Assert.assertEquals('F', new Person("Rochita","Bagchi",'F').getGender());
	}
	
	@Test
	public void testForDisplayDetails() {
		Assert.assertEquals("Firstname=Rochita LastName=Bagchi Gender=F", new Person("Rochita","Bagchi",'F').displayDetails());
	}


}
