package com.cg.mra.exception;

public class InvalidAccountException extends Exception {

	public InvalidAccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
