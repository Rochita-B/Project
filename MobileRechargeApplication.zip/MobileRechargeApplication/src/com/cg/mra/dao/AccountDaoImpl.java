package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDAO{
	Map<String,Account>accountEntry;
	public  AccountDaoImpl() {
		accountEntry=new HashMap();
		accountEntry.put("9010210131", new Account("prepaid","Vaishali",200));
		accountEntry.put("9823920123", new Account("prepaid","Megha",453));
		accountEntry.put("9932012345", new Account("prepaid","Vikas",631));
		accountEntry.put("9010210132", new Account("prepaid","Anju",521));
		accountEntry.put("9010210133", new Account("prepaid","Tushar",632));
	}
	@Override
	public Account getAccountDetails(String mobileNo) {
		return accountEntry.get(mobileNo);
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double acc;
		acc= accountEntry.get(mobileNo).getAccountBalance()+rechargeAmount;

		return acc;
	}

}