package com.cg.mra.client;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidAccountException;
import com.cg.mra.services.AccountServices;
import com.cg.mra.services.AccountServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAccountException {
		Scanner sc=new Scanner(System.in);
		AccountServices services=new AccountServicesImpl();
		while(true) {
		System.out.println("Enter Your Choice Of Operation");
		System.out.println("1) Account Balance Entry \n2)RechargeAccount \n3)Exit");
		int choice=sc.nextInt();
	
		switch(choice){
		case 1:
			System.out.println("Account Balance:");
			System.out.println("Enter Mobile No: ");
			String mobileNo=sc.next();
			Account account=services.getAccountDetails(mobileNo);
			System.out.println("Your Current Balance is: "+account.getAccountBalance());break;
		case 2:
			System.out.println("Enter Mobile Number");
			String mobileNo1=sc.next();
			Account account1=services.getAccountDetails(mobileNo1);
			System.out.println("Enter Recharge Amount: ");
			double rechargeAmt=sc.nextDouble();
			account1.setAccountBalance(account1.getAccountBalance()+rechargeAmt);
			System.out.println("Your account recharged successfully");
			System.out.println("Hello "+account1.getCustomerName()+", Available Balance is Rs."+account1.getAccountBalance());
			break;
		case 3:
			System.out.println("exit");
			System.exit(-1);
		}
		}
			
			
		}
	}

