package com.cg.mra.services;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDAO;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.InvalidAccountException;

public class AccountServicesImpl implements AccountServices{
	AccountDAO accounts=new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidAccountException {
    Account account=new Account();
    if(mobileNo.equals("901021031")||mobileNo.equals("9823920123")||mobileNo.equals("9932012345")||mobileNo.equals("9010210132")
    		||mobileNo.equals("9010210133"))
    	return account;
    else
		throw new InvalidAccountException();
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
	
		return accounts.rechargeAccount(mobileNo, rechargeAmount);
	}

}
