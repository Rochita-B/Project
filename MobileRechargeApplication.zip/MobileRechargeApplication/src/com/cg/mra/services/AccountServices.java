package com.cg.mra.services;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidAccountException;

public interface AccountServices {
Account getAccountDetails(String mobileNo) throws InvalidAccountException;
double rechargeAccount(String mobileNo,double rechargeAmount);

}
