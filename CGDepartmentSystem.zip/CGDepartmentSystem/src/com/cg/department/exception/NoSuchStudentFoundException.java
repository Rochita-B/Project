package com.cg.department.exception;

public class NoSuchStudentFoundException extends Exception {

	public NoSuchStudentFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchStudentFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchStudentFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NoSuchStudentFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NoSuchStudentFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
