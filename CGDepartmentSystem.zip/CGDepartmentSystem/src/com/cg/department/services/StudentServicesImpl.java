package com.cg.department.services;

import java.util.HashMap;
import java.util.Map;

import com.cg.department.beans.Student;
import com.cg.department.dao.StudentDAO;
import com.cg.department.dao.StudentDaoImpl;
import com.cg.department.exception.NoSuchStudentFoundException;

public class StudentServicesImpl implements StudentServices{
StudentDAO students=new StudentDaoImpl();

@Override
public int acceptStudentDetails(Student student) {
	int stud=students.insertStudent(student);
	return stud;
}

	@Override
	public Map<Integer, Student> getAllStudentDetails() {
		return students.findAll();
	}

	@Override
	public HashMap<Integer,Student> getStudentDetails(int studentId) throws NoSuchStudentFoundException {		
		return students.findOneStudent(studentId);
	}

	

}
