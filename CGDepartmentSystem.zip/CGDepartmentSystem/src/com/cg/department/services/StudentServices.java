package com.cg.department.services;

import java.util.HashMap;
import java.util.Map;

import com.cg.department.beans.*;
import com.cg.department.exception.NoSuchStudentFoundException;


public interface StudentServices {
	int acceptStudentDetails(Student student);
	Map<Integer, Student> getAllStudentDetails();
	HashMap<Integer,Student> getStudentDetails(int studentId) throws NoSuchStudentFoundException;
}
