package com.cg.department.ui;

import java.util.Scanner;

import com.cg.department.beans.Student;
import com.cg.department.services.StudentServices;
import com.cg.department.services.StudentServicesImpl;

public class Client {

	public static void main(String[] args) {
	StudentServices services=new StudentServicesImpl() ;
		System.out.println("WELCOME TO XYZ UNIVERSITY!!!!!!!!!!!");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first name of the student: ");
		String firstName=sc.next();
		System.out.println("enter last name of the student: ");
		String lastName=sc.next();
		System.out.println("enter the emailId: ");
		String emailId=sc.next();
		System.out.println("enter the mobile number: ");
		long mobileNo=sc.nextLong();
		System.out.println("enter the department name: ");
		String deptName=sc.next();
		System.out.println("Student details entered successfully!");
		
		Student student=new Student(firstName, lastName, emailId, mobileNo);
		int studId=services.acceptStudentDetails(student);
		System.out.println("the student id is: "+studId);
	}
}
