package com.cg.department.dao;

import java.util.HashMap;

import com.cg.department.beans.Department;
import com.cg.department.beans.Student;
import com.cg.department.util.CollectionUtil;

public class StudentDaoImpl implements StudentDAO{
	
	@Override
	public int insertStudent(Student student) {
		student.setStudentId(CollectionUtil.STUDENT_ID);
		CollectionUtil.studentEntry.put(student.getStudentId(), student);
		return student.getStudentId();
	}

	@Override
	public int insertDept(Department department) {
		department.setDeptId(CollectionUtil.DEPARTMENT_ID);
		CollectionUtil.departmentEntry.put(department.getDeptId(), department);
		return department.getDeptId();
	}


	@Override
	public HashMap<Integer,Student> findOneStudent(int i) {
		return CollectionUtil.getSTUDENT_ID();
	}

	@Override
	public HashMap<Integer, Student> findAll() {
		return CollectionUtil.studentEntry;
	}

	@Override
	public HashMap<Integer, Department> findOneDept(int i) {
		
		return CollectionUtil.getDEPARTMENT_ID();
	}

	



}
