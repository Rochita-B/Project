package com.cg.department.dao;

import java.util.HashMap;

import com.cg.department.beans.Department;
import com.cg.department.beans.Student;

public interface StudentDAO {
public int insertStudent(Student student);
public int insertDept(Department department);
HashMap<Integer, Student> findOneStudent(int i);
HashMap<Integer, Department> findOneDept(int i);
HashMap<Integer, Student>findAll();

}
