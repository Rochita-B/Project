package com.cg.department.util;

import java.util.HashMap;

import com.cg.department.beans.Department;
import com.cg.department.beans.Student;

public class CollectionUtil {
	public static HashMap<Integer, Student>studentEntry=new HashMap<>();
	public static HashMap<Integer, Department>departmentEntry=new HashMap<>();
	public static int STUDENT_ID=(int) (Math.random()*1000);
	public static int DEPARTMENT_ID=(int) (Math.random()*1000);

	public static HashMap<Integer,Student> getSTUDENT_ID(){
		return studentEntry;
	}
	public static HashMap<Integer, Department>getDEPARTMENT_ID(){
		return departmentEntry;
	}
	

}
