package com.cg.loan.util;

public class CollectionUtil {

	public static long CUSTOMER_ID=(long)Math.random()*1000;
	public static long LOAN_ID=(long)Math.random()*1000;
	public static long getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public static long getLOAN_ID() {
		return LOAN_ID;
	}
	
}
