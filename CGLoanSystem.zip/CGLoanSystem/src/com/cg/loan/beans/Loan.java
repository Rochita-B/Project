package com.cg.loan.beans;

public class Loan {
private long loanId;
private double loanAmount;
private long customerId;
private int duration;
 public Loan() {}
public Loan(long loanId, double loanAmount, long customerId, int duration) {
	super();
	this.loanId = loanId;
	this.loanAmount = loanAmount;
	this.customerId = customerId;
	this.duration = duration;
}
public long getLoanId() {
	return loanId;
}
public void setLoanId(long loanId) {
	this.loanId = loanId;
}
public double getLoanAmount() {
	return loanAmount;
}
public void setLoanAmount(double loanAmount) {
	this.loanAmount = loanAmount;
}
public long getCustomerId() {
	return customerId;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (int) (customerId ^ (customerId >>> 32));
	result = prime * result + duration;
	long temp;
	temp = Double.doubleToLongBits(loanAmount);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + (int) (loanId ^ (loanId >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Loan other = (Loan) obj;
	if (customerId != other.customerId)
		return false;
	if (duration != other.duration)
		return false;
	if (Double.doubleToLongBits(loanAmount) != Double.doubleToLongBits(other.loanAmount))
		return false;
	if (loanId != other.loanId)
		return false;
	return true;
}
@Override
public String toString() {
	return "Loan [loanId=" + loanId + ", loanAmount=" + loanAmount + ", customerId=" + customerId + ", duration="
			+ duration + "]";
}
 
}
