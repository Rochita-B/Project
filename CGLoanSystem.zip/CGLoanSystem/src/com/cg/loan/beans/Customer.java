package com.cg.loan.beans;

public class Customer {
private int customerId;
private String custName, address;
private long mobileNo;
private String emailId;
public Customer() {}
public Customer(int customerId, String custName, String address, long mobileNo, String emailId) {
	super();
	this.customerId = customerId;
	this.custName = custName;
	this.address = address;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
}

public Customer(String custName, String address, long mobileNo, String emailId) {
	super();
	this.custName = custName;
	this.address = address;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ((custName == null) ? 0 : custName.hashCode());
	result = prime * result + customerId;
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + (int) (mobileNo ^ (mobileNo >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (custName == null) {
		if (other.custName != null)
			return false;
	} else if (!custName.equals(other.custName))
		return false;
	if (customerId != other.customerId)
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (mobileNo != other.mobileNo)
		return false;
	return true;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", custName=" + custName + ", address=" + address + ", mobileNo="
			+ mobileNo + ", emailId=" + emailId + "]";
}

}
