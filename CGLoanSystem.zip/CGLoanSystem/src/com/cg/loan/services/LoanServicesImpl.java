package com.cg.loan.services;

import com.cg.loan.beans.Customer;
import com.cg.loan.beans.Loan;
import com.cg.loan.dao.LoanDAO;
import com.cg.loan.dao.LoanDaoImpl;

public class LoanServicesImpl implements LoanServices{
LoanDAO loans= new LoanDaoImpl();
	@Override
	public long applyLoan(Loan loan) {		
		return loans.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer) {
		return null;
	}

	@Override
	public long insertCust(Customer cust) {
		return loans.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		return 0;
	}

}
