package com.cg.loan.services;

import com.cg.loan.beans.*;

public interface LoanServices {
public long applyLoan(Loan loan);
Customer validateCustomer(Customer customer);
public long insertCust(Customer cust);
public double calculateEMI(double amount,int duration);
}
