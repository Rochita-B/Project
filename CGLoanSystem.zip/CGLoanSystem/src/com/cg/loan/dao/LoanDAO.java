package com.cg.loan.dao;
import java.util.HashMap;
import java.util.List;

import com.cg.loan.beans.Customer;
import com.cg.loan.beans.Loan;


public interface LoanDAO {
	
	  HashMap<Integer, Customer> customerEntry=null; 
	  HashMap<Integer, Loan> loanEntry=null;
	  
	public long insertCust(Customer customer);
	List<Customer> findOneCustomer();
	List<Loan>findOneLoan();
	public long applyLoan(Loan loan);
	

	
}
