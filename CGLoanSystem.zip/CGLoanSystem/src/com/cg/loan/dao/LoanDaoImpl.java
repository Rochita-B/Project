package com.cg.loan.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.loan.beans.Customer;
import com.cg.loan.beans.Loan;
import com.cg.loan.util.CollectionUtil;

public class LoanDaoImpl implements LoanDAO{
	
	@Override
	public long applyLoan(Loan loan) {
		loan.setLoanId(CollectionUtil.getLOAN_ID());
		loan.setCustomerId(CollectionUtil.getCUSTOMER_ID());
		this.loanEntry.put((int) loan.getLoanId(), loan);
		return loan.getLoanId();
	}

	@Override
	public long insertCust(Customer customer) {
		 customer.setCustomerId((int) CollectionUtil.getCUSTOMER_ID());
		 this.customerEntry.put(customer.getCustomerId(),customer);
		return customer.getCustomerId();
	}
	HashMap<Integer,Customer>customerEntry=new HashMap<>();
	HashMap<Integer,Loan>loanEntry= new HashMap<>();
	
	@Override
	public List<Customer> findOneCustomer() {
		return (List<Customer>) customerEntry.values();
	}

	@Override
	public List<Loan> findOneLoan() {
		return (List<Loan>) loanEntry.values();
	}
}
