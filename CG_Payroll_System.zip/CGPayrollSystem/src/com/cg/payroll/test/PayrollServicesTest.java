package com.cg.payroll.test;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;


public class PayrollServicesTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv()   {
		services=new PayrollServicesImpl();
	}

	private ArrayList<Associate> expectedAssociateList;
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				new Salary(10000,450000,12000,12000,100050, 10000),new BankDetails(12345, "axis bank","uti23456"));
		Associate associate2=new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				new Salary(13000,400000,15000,15000,100000, 20000),new BankDetails(34567, "icici bank","icic23456"));
		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		services.getAssociateDetails(12345);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				new Salary(10000,450000,12000,12000,100050, 10000),new BankDetails(12345, "axis bank","uti23456")); 
		Associate actualAssociate=services.getAssociateDetails(102);
		Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	@Test
	public void testAcceptAssociateDetailsForValiddata() {
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("abc", "pqr", "abc@gmail.com", "YTP", "analyst", "pan1234", 120000, 10000, 3000, 2500, 123456, "HDFC");
		Assert.assertEquals(expectedId, actualId);
	}
	@Test
	public void testcalculateNetSalaryForInvalidAssociate() throws AssociateDetailsNotFoundException{
		services.calculateNetSalary(1434);
	}
	@Test
	public void testcalculateNetSalaryForValidAssociate() throws AssociateDetailsNotFoundException{
		double expectedNetSalary=0;
		double actualNetSalary=services.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary,0);
	}
	@Test
	public void testCalculateGrossSalaryForInvalidAssociate() throws AssociateDetailsNotFoundException{
		services.calculateGrossSalary(1434);
	}
	@Test
	public void testcalculateGrossSalaryForValidAssociate() throws AssociateDetailsNotFoundException{
		double expectedGrossSalary=0;
		double actualGrossSalary=services.calculateNetSalary(102);
		Assert.assertEquals(expectedGrossSalary, actualGrossSalary,0);
	}
	
	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1=new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				new Salary(10000,450000,12000,12000,100050, 10000),new BankDetails(12345, "axis bank","uti23456"));
		Associate associate2=new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				new Salary(13000,400000,15000,15000,100000, 20000),new BankDetails(34567, "icici bank","icic23456"));
		
		ArrayList<Associate>expectedAssociateList=new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		
		ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)services.getAllAssociatesDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);

	}
	@After
	public void tearDownTestData() {
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}

	@AfterClass
	public static void tearDownTestEnv()   {
		services=null;
	}
}
