package com.cg.payroll.client;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class MainClass 
{

	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Rochita", "Bagchi","rochita@gmail.com","Student","Analyst","abc1235",10000,450000,12000,12000,100050,"axis bank","uti23456");
		int associateId1=services.acceptAssociateDetails("Haya", "Fatima","hayafatima@gmail.com","Student","Analyst","abc1234",10000,400000,12000,12000,100050,"icici bank","icic23456");
		int associateId2=services.acceptAssociateDetails("Gunjan", "Vohra","gunjanvohra@gmail.com","Student","Analyst","abc1236",10000,750000,12000,12000,100050,"axis bank","uti23456");
		int associateId3=services.acceptAssociateDetails("Rishita", "Bagchi","bagchirishita@gmail.com","Student","Analyst","abc1237",10000,750000,12000,12000,100050,"citi bank","cit123456");
		int associateId4=services.acceptAssociateDetails("Rupali", "Roy","rupaliroy@gmail.com","Student","Analyst","abc1238",10000,700000,13000,12000,100050,"citi bank","cit12101");
		try {
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"   --->Net Annual salary : "+services.calculateNetSalary(associateId));
		     double monNetSalary=(services.calculateNetSalary(associateId))/12;
		     System.out.println("---->monthly net salary: "+monNetSalary);
		    
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId1));
		    double monNetSalary1=(services.calculateNetSalary(associateId1))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary1);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId2));
		    double monNetSalary2=(services.calculateNetSalary(associateId2))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary2);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId3));
		    double monNetSalary3=(services.calculateNetSalary(associateId3))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary3);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId4));
		    double monNetSalary4=(services.calculateNetSalary(associateId4))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary3);
		   }
		catch(AssociateDetailsNotFoundException e)
		{
			e.printStackTrace();
		}
	}
}


